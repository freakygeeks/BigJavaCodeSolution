package jsfks;

public class PersonBean {

   String personName;
	
   /**
   * @return Person Name
   */
   public String getPersonName() {
      return personName;
   }

   /**
   * @param Person Name
   */
   public void setPersonName(String name) {
      personName = name;
   }
}